<meta charset="utf-8">
<meta http-equiv="X-UA-Compatible" content="IE=edge">
<meta name="viewport" content="width=device-width, initial-scale=1">

<meta name="description" content="Official website of themepark, where your kids will enjoy">
<meta name="author" content="Saam Mohamed"><?php /**PATH C:\wamp64\www\themepark.com\resources\views/layouts/meta.blade.php ENDPATH**/ ?>