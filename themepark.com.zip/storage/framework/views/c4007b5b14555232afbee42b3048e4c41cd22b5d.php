<footer class="page-footer font-small blue">

<div class="footer-copyright text-center mdb-color pt-4">&copy;
<?php if(date('Y') > 2019): ?>
2019 - <?php echo e(date('Y')); ?>

<?php else: ?>
2019
<?php endif; ?>
All rights Reserved to Saam Mohamed.
<a href="http://themepark.com">Themepark.com</a></div>
</footer><?php /**PATH C:\wamp64\www\themepark.com\resources\views/layouts/bottom.blade.php ENDPATH**/ ?>