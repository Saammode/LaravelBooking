
<?php $__env->startSection('title'); ?>
<title>Home of Theme Park</title>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<h1>Welcome to the theme park</h1>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\wamp64\www\themepark.com\resources\views/index.blade.php ENDPATH**/ ?>