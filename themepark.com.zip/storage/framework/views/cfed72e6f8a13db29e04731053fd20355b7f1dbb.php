<!DOCTYPE html>
<html land="en">
<head>
<?php echo $__env->make('layouts.meta', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<link rel="icon" href="../../favicon.ico">
<?php echo $__env->yieldContent('title'); ?>
<?php echo $__env->make('layouts.css', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>;
<?php echo $__env->yieldContent('css'); ?>
</head>
<body role="document">
<?php echo $__env->make('layouts.nav', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<div class="container theme-showcase" role="main">
<?php echo $__env->yieldContent('content'); ?>
<?php echo $__env->make('layouts.bottom', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<?php echo $__env->make('layouts.scripts', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<?php echo $__env->yieldContent('scripts'); ?>
</body>
</html>
<?php /**PATH C:\wamp64\www\themepark.com\resources\views/layouts/master.blade.php ENDPATH**/ ?>