<script src="/js/app.js"></script>
<script src="/js/sweetalert.js"></script><?php /**PATH C:\wamp64\www\themepark.com\resources\views/layouts/scripts.blade.php ENDPATH**/ ?>