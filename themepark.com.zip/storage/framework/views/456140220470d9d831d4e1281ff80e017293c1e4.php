<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
<link href="/css/app.css" rel="stylesheet">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/font-awesome/4.5.0/css/font-awesome.min.css">

<link rel="stylesheet" type="text/css" href="/css/sweetalert.css">
<style>
body{
  padding-top: 65px;
  background-color: light-blue;
}
</style>
<?php /**PATH C:\wamp64\www\themepark.com\resources\views/layouts/css.blade.php ENDPATH**/ ?>