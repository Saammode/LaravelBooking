@extends('layouts.master')
@section('title')
<title>Home of Theme Park</title>
@endsection
@section("content")
<h1>Welcome to the theme park</h1>
@endsection