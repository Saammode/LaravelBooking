<nav class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
<div class="navbar-header">

<a class="navbar-brand" href="/">Home</a>
<a class="navbar-brand" href="/customer">Customer</a>
<a class="navbar-brand" href="/hotel">Hotels</a>
<a class="navbar-brand" href=/room>Rooms</a>
<a class="navbar-brand" href="/activity">Activities</a>
<a class="navbar-brand" href="/schedule">Schedule</a>
</div>

<div id="navbar" class="navbar-collapse collapse pull-right">
<ul class="nav navbar-nav">
<li class="active"><a href="/">Contact</a></li>
<li><a href="#about">About</a></li>
<li><a href="/login">Login</a></li>
<li><a href="/register">Register</a></li>
</ul>
</div>
</div>
</nav>