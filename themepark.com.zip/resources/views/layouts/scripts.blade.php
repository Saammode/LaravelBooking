<script src="/js/app.js"></script>
<script src="/js/sweetalert.js"></script>