<footer class="page-footer font-small blue">

<div class="footer-copyright text-center mdb-color pt-4">&copy;
@if (date('Y') > 2019)
2019 - {{date('Y')}}
@else
2019
@endif
All rights Reserved to Saam Mohamed.
<a href="http://themepark.com">Themepark.com</a></div>
</footer>